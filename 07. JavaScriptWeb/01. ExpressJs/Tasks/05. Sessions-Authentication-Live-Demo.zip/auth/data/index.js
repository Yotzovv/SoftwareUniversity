var mongoose = require('mongoose');
var connectionStr = 'use your connection string here';

mongoose.connect(connectionStr);