function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};function greet(name, beforeMsgSent, afterMsgSentCb) {
    const message = `Hi ${name}`;
    
    beforeMsgSent();
    console.log(message);
    afterMsgSentCb(message);
}

function formalGreet(name) {
    console.log(`Hello, ${name} ! How do you do ?`);
}

module.exports = {
    greet,
    formalGreet,
};