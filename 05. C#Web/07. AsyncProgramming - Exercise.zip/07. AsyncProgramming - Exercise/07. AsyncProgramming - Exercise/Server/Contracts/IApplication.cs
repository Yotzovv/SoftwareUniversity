﻿public interface IApplication
{
    void Configure(IAppRouteConfig appRouteConfig);
}
