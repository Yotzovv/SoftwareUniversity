﻿public interface IApplication
{
    void Start(IAppRouteConfig appRouteConfig);
}
