﻿public interface IView
{
    string View();
}

