﻿public interface IHttpContext
{
    IHttpRequest Request { get; }
}
