﻿public enum HttpRequestMethod
{
    Get,
    Post
}
