﻿public class IndexView : IView
{
    public string View()
    {
        return "<body><h1>Welcome</h1></body>";
    }
}