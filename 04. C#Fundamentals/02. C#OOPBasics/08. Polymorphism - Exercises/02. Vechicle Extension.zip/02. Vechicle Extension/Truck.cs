﻿namespace _02.Vechicle_Extension
{
    public class Truck : Vechicle
    {
        public Truck(double fuelQuantity, double fuelConsumption, double tank)
            : base (fuelQuantity, fuelConsumption, tank)
        {
        }
    }
}
