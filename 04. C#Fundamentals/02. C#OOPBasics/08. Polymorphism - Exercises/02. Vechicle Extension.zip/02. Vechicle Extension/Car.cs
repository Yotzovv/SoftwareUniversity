﻿namespace _02.Vechicle_Extension
{
    public class Car : Vechicle
    {
        public Car(double fuelQuantity, double fuelConsumption, double tank)
            : base(fuelQuantity, fuelConsumption, tank)
        {
        }
    }
}
