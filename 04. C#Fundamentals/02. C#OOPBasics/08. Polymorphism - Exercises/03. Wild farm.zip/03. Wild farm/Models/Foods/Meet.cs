﻿namespace _03.Wild_farm.Models.Foods
{
    public class Meet : Food
    {
        public Meet(int quantity) : base (quantity)
        {
        }
    }
}
