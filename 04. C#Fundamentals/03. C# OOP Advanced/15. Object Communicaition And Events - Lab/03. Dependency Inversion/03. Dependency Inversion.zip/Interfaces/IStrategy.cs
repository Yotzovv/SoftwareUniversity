﻿namespace _03.Dependency_Inversion.Interfaces
{
    public interface IStrategy
    {
        int Calculate(int first, int second);
    }
}
