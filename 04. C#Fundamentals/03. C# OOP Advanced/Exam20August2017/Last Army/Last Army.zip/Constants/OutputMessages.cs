﻿public class OutputMessages
{
    public const string MissionDeclined = "Mission {0} is declined!";
    public const string MissionSuccessful = "Mission {0} is successful!";
    public const string MissionOnHold = "Mission {0} is on hold!";
}

